/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

#ifndef K_API_H
#define K_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include <k_types.h>

#ifdef __cplusplus
}
#endif

#endif /* K_API_H */

