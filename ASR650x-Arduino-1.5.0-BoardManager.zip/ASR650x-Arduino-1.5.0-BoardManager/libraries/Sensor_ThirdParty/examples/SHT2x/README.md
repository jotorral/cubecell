This is an Arduino library for the SHT21 / SHT25 humidity and temperature sensors.
