Grove - Temp&Humi&Barometer Sensor (BME280)
------------
<img src=https://raw.githubusercontent.com/SeeedDocument/Grove-Barometer_Sensor-BME280/master/img/Grove-Barometer_Sensor-BMP280-700_s.jpg width=300><img src=https://statics3.seeedstudio.com/seeed/img/2016-06/qgrfZSEmJqN7KPBR7NJKaNl1.jpg width=300>

[Grove - Temp&Humi&Barometer Sensor (BME280)](https://www.seeedstudio.com/s/Grove-Temp%26Humi%26Barometer-Sensor-(BME280)-p-2653.html)

Grove - Barometer Sensor (BME280) is a breakout board for Bosch BMP280 high-precision, low-power combined humidity, pressure, and temperature sensor. This module can be used to measure temperature, atmospheric pressure and humidity accurately and fast. As the atmospheric pressure changes with altitude, it can also measure approximate altitude of a place.

More information please visit [wiki page](http://wiki.seeedstudio.com/Grove-Barometer_Sensor-BME280/).

----

This software is written by Lambor Fang (shijian.fanG@seeed.cc) for seeed studio<br>
and is licensed under [The MIT License](http://opensource.org/licenses/mit-license.php). Check License.txt for more information.<br>


Seeed Studio is an open hardware facilitation company based in Shenzhen, China. <br>
Benefiting from local manufacture power and convenient global logistic system, <br>
we integrate resources to serve new era of innovation. Seeed also works with <br>
global distributors and partners to push open hardware movement.<br>


[![Analytics](https://ga-beacon.appspot.com/UA-46589105-3/Grove_BME280)](https://github.com/igrigorik/ga-beacon)

